Configuration DiskPrepAndTest
{


	Param(
		#Target nodes to apply the configuration 
		[Parameter(Mandatory = $false)] 
		[ValidateNotNullorEmpty()] 
		[String]$SystemTimeZone="GMT Standard Time",

		[Parameter(Mandatory = $true)]
		[ValidateNotNullorEmpty()] 
		[String]$diskSpdDownloadUrl, # https://gallery.technet.microsoft.com/DiskSpd-A-Robust-Storage-6ef84e62/file/199535/1/DiskSpd-2.0.20a.zip

		[Parameter(Mandatory = $false)]
		[ValidateNotNullorEmpty()] 
		[String]$testParams,

		[Parameter(Mandatory = $true)]
		[ValidateNotNullorEmpty()] 
		[String]$testName,

		[String]$storageAccountKey, # from the properties of the storage account
		[String]$storageContainerName,  
		[String]$storageAccountName,
		[String]$storageUrlDomain = 'blob.core.windows.net', # this will be different for an Azure Stack
		
		[String]$uploadUrlWithSas # this is used for the network test of uploading and downloading a file
		
	)
 
		
	# Modules to Import
	Import-DscResource �ModuleName PSDesiredStateConfiguration, ComputerManagementDsc, FileDownloadDSC, StackTestHarness
 
	Node localhost
	{
		LocalConfigurationManager 
        { 
            # This is false by default
            RebootNodeIfNeeded = $true
			ConfigurationMode = 'ApplyOnly'
        } 

		TimeZone TimeZoneExample 
		{ 
			IsSingleInstance = 'Yes'
			TimeZone = $SystemTimeZone 
		} 

		#WindowsFeature Containers
		#{
		#	Name = "Containers"
		#	Ensure = "Present"
		#}
 
		WindowsFeature SMBv1 
		{
			Name = "FS-SMB1"
			Ensure = "Absent" 
		}

		File ResultsDirectory
		{
			DestinationPath = 'C:\results'
			Ensure = "Present"
			Type = 'Directory'
		}

 		Script StoragePool 
		{
			SetScript = { 
				New-StoragePool -FriendlyName StoragePool1 -StorageSubSystemFriendlyName '*storage*' -PhysicalDisks (Get-PhysicalDisk �CanPool $True)
			}
			TestScript = {
				(Get-StoragePool -ErrorAction SilentlyContinue -FriendlyName StoragePool1).OperationalStatus -eq 'OK'
			}
			GetScript = {
				@{Ensure = if ((Get-StoragePool -FriendlyName StoragePool1).OperationalStatus -eq 'OK') {'Present'} Else {'Absent'}}
			}
		}
	
		Script VirtualDisk 
		{
			SetScript = { 
				$disks = Get-StoragePool �FriendlyName StoragePool1 -IsPrimordial $False | Get-PhysicalDisk
 
				$diskNum = $disks.Count
				New-VirtualDisk �StoragePoolFriendlyName StoragePool1 �FriendlyName VirtualDisk1 �ResiliencySettingName simple -NumberOfColumns $diskNum �UseMaximumSize 
			}
			TestScript = {
				(get-virtualdisk -ErrorAction SilentlyContinue -friendlyName VirtualDisk1).operationalSatus -EQ 'OK' 
			}
			GetScript = { 
				@{Ensure = if ((Get-VirtualDisk -FriendlyName VirtualDisk1).OperationalStatus -eq 'OK') {'Present'} Else {'Absent'}}
			}
			DependsOn = "[Script]StoragePool"
		}
		
		Script FormatDisk 
		{ 
			SetScript = { 
				Get-VirtualDisk �FriendlyName VirtualDisk1 | Get-Disk | Initialize-Disk �Passthru | New-Partition �AssignDriveLetter �UseMaximumSize | Format-Volume -NewFileSystemLabel VirtualDisk1 �AllocationUnitSize 64KB -FileSystem NTFS
			}
			TestScript = { 
				(get-volume -ErrorAction SilentlyContinue -filesystemlabel VirtualDisk1).filesystem -EQ 'NTFS'
			} 
			GetScript = { 
				@{Ensure = if ((get-volume -filesystemlabel VirtualDisk1).filesystem -EQ 'NTFS') {'Present'} Else {'Absent'}}
			} 
			DependsOn = "[Script]VirtualDisk" 
		}


		FileDownload DiskSpdDownload
        {
            FileName = "c:\diskspd.zip"
            Url = $diskSpdDownloadUrl
			DependsOn = "[Script]FormatDisk"
        }

		Archive UncompressDiskSpd
        {
            Path = "c:\diskspd.zip"
            Destination = "c:\DiskSpd"
			DependsOn = "[FileDownload]DiskSpdDownload"
        }

		DiskSpdTest test
		{
			TestName = $testName
			PhysicalPathToDiskSpd = "C:\DiskSpd\amd64\"
			ResultsOutputDirectory = "C:\results"
			DiskSpdParameters = $testParams
			StorageAccountName = $storageAccountName
			StorageContainerName = $storageContainerName
			StorageAccountKey = $storageAccountKey
			StorageUrlDomain = $storageUrlDomain
			UploadUrlWithSas = $uploadUrlWithSas
			Ensure = "Present"
			DependsOn = "[Archive]UncompressDiskSpd"
		}



	}





}


