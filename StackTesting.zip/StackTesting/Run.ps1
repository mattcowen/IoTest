Set-AzureRmDefaultProfile -Profile '2018-03-01-hybrid'

Get-Module # shows limited number of modules

Import-Module AzureRM

Get-Module # seems to show everything loaded and Get-AzureRmStorageAccount works

$cred = Get-Credential -UserName "mcowen" -Message "VM Admin cred"

Set-Location -Path C:\dev\mod\StackTesting\StackTesting

# this fails
.\RampTest.ps1 -cred $cred -totalVmCount 1 -pauseBetweenVmCreateInSeconds 5 -location 'mas2' -vmsize 'Standard_F2s_v2' `
    -storageUrlDomain 'blob.mas2.mtc-tvp.com' -testParams '-c200M -t2 -o20 -d30 -w50 -Rxml' -dataDiskSizeGb 128 `
     -resourceGroupNamePrefix 'ST-' -password $cred.Password -dontDeleteResourceGroupOnComplete



